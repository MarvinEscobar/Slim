CREATE DATABASE  IF NOT EXISTS `heroku_004e7f388adb8a1` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `heroku_004e7f388adb8a1`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: us-cdbr-iron-east-04.cleardb.net    Database: heroku_004e7f388adb8a1
-- ------------------------------------------------------
-- Server version	5.5.56-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id_accounts` int(6) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `dui` varchar(10) NOT NULL,
  `nit` varchar(17) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `backup_phone` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `date_birth` date NOT NULL,
  `gender` int(1) NOT NULL,
  `notifications` int(1) NOT NULL,
  `invitation_code` varchar(8) NOT NULL,
  `ranking` int(11) DEFAULT '1',
  `access_information` int(1) NOT NULL,
  `status` int(11) DEFAULT '1',
  `comment` mediumtext,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_accounts`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (000002,'222222222','222222222','Eduardo','Linares','elinares@elaniin.com','+22577777','+22577777','El Salvador','San Salvador','Santa Tecla','lorem ipsum dolor sit ament','1990-01-01',1,1,'HL1MPT0Z',2,1,2,NULL,'2018-05-12 04:22:52'),(000022,'045914862','06021801921069','Marvin','Escobar','marvin@elaniin.com','+50370848731','+50370848731','El Salvador','San Salvador','Apopa','lorem ipsum dolor sit ament #50','0000-00-00',1,1,'4FK1ECLN',1,1,2,'','2018-05-08 23:13:35'),(000032,'045914862','06021801921069','Marvin','Escobar','marvin@elaniin.com','+50370848731','+50370848731','El Salvador','San Salvador','Apopa','lorem ipsum dolor sit ament #50','0000-00-00',1,1,'1V4XIWUU',1,1,1,NULL,'2018-05-09 23:10:30');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_pay`
--

DROP TABLE IF EXISTS `accounts_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_pay` (
  `id_accounts_pay` int(11) NOT NULL AUTO_INCREMENT,
  `id_accounts` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `account_number` int(11) NOT NULL,
  `user_account` varchar(20) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_accounts_pay`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_pay`
--

LOCK TABLES `accounts_pay` WRITE;
/*!40000 ALTER TABLE `accounts_pay` DISABLE KEYS */;
INSERT INTO `accounts_pay` VALUES (1,4,1,123981203,'hola','39129lsdjlasdl','2018-05-03 20:54:41');
/*!40000 ALTER TABLE `accounts_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `answers_steps`
--

DROP TABLE IF EXISTS `answers_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answers_steps` (
  `id_answers_steps` int(11) NOT NULL AUTO_INCREMENT,
  `id_accounts` int(11) NOT NULL,
  `id_step` int(11) NOT NULL,
  `id_questions` int(11) NOT NULL,
  `answers` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_answers_steps`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answers_steps`
--

LOCK TABLES `answers_steps` WRITE;
/*!40000 ALTER TABLE `answers_steps` DISABLE KEYS */;
INSERT INTO `answers_steps` VALUES (12,22,12,22,'SV','2018-05-09 06:35:23'),(22,22,12,12,'300','2018-05-09 06:37:01');
/*!40000 ALTER TABLE `answers_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `confirm_code`
--

DROP TABLE IF EXISTS `confirm_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `confirm_code` (
  `id_confirm_code` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `pin` varchar(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_confirm_code`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `confirm_code`
--

LOCK TABLES `confirm_code` WRITE;
/*!40000 ALTER TABLE `confirm_code` DISABLE KEYS */;
INSERT INTO `confirm_code` VALUES (1,'+50370848731','1211','2018-04-22 00:30:55'),(2,'+50370848732','4214','2018-04-22 00:34:10');
/*!40000 ALTER TABLE `confirm_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_detail`
--

DROP TABLE IF EXISTS `credit_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_detail` (
  `id_credit_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_credits` int(11) NOT NULL,
  `id_accounts_pay` int(11) NOT NULL,
  `periods_payment` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credit_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_detail`
--

LOCK TABLES `credit_detail` WRITE;
/*!40000 ALTER TABLE `credit_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_installment_status`
--

DROP TABLE IF EXISTS `credit_installment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_installment_status` (
  `id_credit_installment_status` int(11) NOT NULL AUTO_INCREMENT,
  `id_credits` int(11) NOT NULL,
  `id_credit_payment_date` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credit_installment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_installment_status`
--

LOCK TABLES `credit_installment_status` WRITE;
/*!40000 ALTER TABLE `credit_installment_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_installment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_payment_date`
--

DROP TABLE IF EXISTS `credit_payment_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_payment_date` (
  `id_credit_payment_date` int(11) NOT NULL AUTO_INCREMENT,
  `id_credits` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_credit_payment_date`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_payment_date`
--

LOCK TABLES `credit_payment_date` WRITE;
/*!40000 ALTER TABLE `credit_payment_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_payment_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits`
--

DROP TABLE IF EXISTS `credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credits` (
  `id_credits` int(11) NOT NULL AUTO_INCREMENT,
  `id_accounts` int(11) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `comment_status` varchar(300) DEFAULT NULL,
  `notified` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_credits`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credits`
--

LOCK TABLES `credits` WRITE;
/*!40000 ALTER TABLE `credits` DISABLE KEYS */;
INSERT INTO `credits` VALUES (12,22,20.00,2,NULL,1,'2018-05-12 01:14:29'),(22,22,20.00,6,NULL,1,'2018-05-12 05:53:53'),(32,22,39.00,1,NULL,0,'2018-05-12 05:53:53'),(42,22,40.00,2,NULL,1,'2018-05-12 05:53:53'),(52,22,40.00,6,NULL,1,'2018-05-12 05:53:53'),(62,22,30.00,6,NULL,1,'2018-05-12 05:53:53');
/*!40000 ALTER TABLE `credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `default_answers`
--

DROP TABLE IF EXISTS `default_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_answers` (
  `id_default_answers` int(11) NOT NULL AUTO_INCREMENT,
  `id_questions` int(11) NOT NULL,
  `answers` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_default_answers`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `default_answers`
--

LOCK TABLES `default_answers` WRITE;
/*!40000 ALTER TABLE `default_answers` DISABLE KEYS */;
INSERT INTO `default_answers` VALUES (12,12,'100',1),(22,12,'200',1),(32,22,'SV',1),(42,12,'300',1);
/*!40000 ALTER TABLE `default_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id_payments` int(11) NOT NULL AUTO_INCREMENT,
  `id_credits` int(11) NOT NULL,
  `id_credit_payment_date` int(11) NOT NULL,
  `id_accounts_pay` int(11) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_payments`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periods_payment`
--

DROP TABLE IF EXISTS `periods_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periods_payment` (
  `id_periods_payment` int(11) NOT NULL AUTO_INCREMENT,
  `period` int(2) NOT NULL,
  `interest` float(4,2) DEFAULT NULL,
  `pay` int(11) NOT NULL,
  PRIMARY KEY (`id_periods_payment`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periods_payment`
--

LOCK TABLES `periods_payment` WRITE;
/*!40000 ALTER TABLE `periods_payment` DISABLE KEYS */;
INSERT INTO `periods_payment` VALUES (1,15,20.00,4),(2,21,38.00,6);
/*!40000 ALTER TABLE `periods_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_data`
--

DROP TABLE IF EXISTS `phone_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone_data` (
  `id_phone_data` int(11) NOT NULL AUTO_INCREMENT,
  `id_accounts` int(11) NOT NULL,
  `log_calls` text,
  `log_sms` text,
  `log_location` text,
  `log_apps` text,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_phone_data`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_data`
--

LOCK TABLES `phone_data` WRITE;
/*!40000 ALTER TABLE `phone_data` DISABLE KEYS */;
INSERT INTO `phone_data` VALUES (2,22,'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','2018-05-09 06:41:48'),(12,22,'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam accusantium ratione necessitatibus, reprehenderit vel expedita ea id nisi quod, doloremque fugiat dicta, commodi ullam! Nobis maxime tempora, beatae fugiat minima.','2018-05-12 00:22:27');
/*!40000 ALTER TABLE `phone_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id_questions` int(11) NOT NULL AUTO_INCREMENT,
  `questions` varchar(300) NOT NULL,
  `type_question` int(1) NOT NULL,
  `step` int(11) NOT NULL,
  `parent` int(11) DEFAULT '0',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_questions`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (12,'Cuanto ganas?',2,12,0,1),(22,'Pais',3,12,12,1),(42,'¿COLOR FAVORITO?',2,22,0,1);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranking`
--

DROP TABLE IF EXISTS `ranking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ranking` (
  `id_ranking` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `amount_min` float(10,2) NOT NULL,
  `amount_max` float(10,2) NOT NULL,
  PRIMARY KEY (`id_ranking`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking`
--

LOCK TABLES `ranking` WRITE;
/*!40000 ALTER TABLE `ranking` DISABLE KEYS */;
INSERT INTO `ranking` VALUES (1,'BRONCE',20.00,40.00),(2,'PLATA',40.00,80.00),(3,'ORO',80.00,200.00);
/*!40000 ALTER TABLE `ranking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_code`
--

DROP TABLE IF EXISTS `security_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_code` (
  `id_security_code` int(11) NOT NULL AUTO_INCREMENT,
  `id_accounts` int(11) DEFAULT NULL,
  `pin` varchar(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_security_code`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_code`
--

LOCK TABLES `security_code` WRITE;
/*!40000 ALTER TABLE `security_code` DISABLE KEYS */;
INSERT INTO `security_code` VALUES (2,8,'1234','2018-05-08 20:19:31'),(12,22,'1234','2018-05-08 23:15:25');
/*!40000 ALTER TABLE `security_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `step`
--

DROP TABLE IF EXISTS `step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `step` (
  `id_step` int(11) NOT NULL AUTO_INCREMENT,
  `name_step` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_step`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `step`
--

LOCK TABLES `step` WRITE;
/*!40000 ALTER TABLE `step` DISABLE KEYS */;
INSERT INTO `step` VALUES (12,'setp 1',1),(22,'setp 2 ',1),(32,'dsfsdfdsf',1);
/*!40000 ALTER TABLE `step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_accounts_pay`
--

DROP TABLE IF EXISTS `type_accounts_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_accounts_pay` (
  `id_type_accounts_pay` int(11) NOT NULL AUTO_INCREMENT,
  `name_accounts` varchar(50) NOT NULL,
  PRIMARY KEY (`id_type_accounts_pay`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_accounts_pay`
--

LOCK TABLES `type_accounts_pay` WRITE;
/*!40000 ALTER TABLE `type_accounts_pay` DISABLE KEYS */;
INSERT INTO `type_accounts_pay` VALUES (1,'MOMO');
/*!40000 ALTER TABLE `type_accounts_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_level`
--

DROP TABLE IF EXISTS `user_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_level` (
  `id_level` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_level`
--

LOCK TABLES `user_level` WRITE;
/*!40000 ALTER TABLE `user_level` DISABLE KEYS */;
INSERT INTO `user_level` VALUES (1,'Super Administrator'),(2,'Administrator'),(3,'Collaborator');
/*!40000 ALTER TABLE `user_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_module`
--

DROP TABLE IF EXISTS `user_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_module` (
  `id_module` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id_module`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_module`
--

LOCK TABLES `user_module` WRITE;
/*!40000 ALTER TABLE `user_module` DISABLE KEYS */;
INSERT INTO `user_module` VALUES (1,'dashboard','./dashboard'),(2,'accounts','./accounts'),(3,'credits','./credits'),(4,'outstanding loans','./outstanding-loans'),(5,'questions','./questions'),(6,'configuration','./configuration'),(7,'dashboard','./dashboard'),(8,'accounts','./accounts'),(9,'credits','./credits'),(10,'outstanding loans','./outstanding-loans'),(11,'questions','./questions'),(12,'configuration','./configuration'),(13,'dashboard','./dashboard'),(14,'accounts','./accounts'),(15,'credits','./credits'),(16,'outstanding loans','./outstanding-loans'),(17,'questions','./questions'),(18,'configuration','./configuration'),(19,'dashboard','./dashboard'),(20,'accounts','./accounts'),(21,'credits','./credits'),(22,'outstanding loans','./outstanding-loans'),(23,'questions','./questions'),(24,'configuration','./configuration'),(25,'dashboard','./dashboard'),(26,'accounts','./accounts'),(27,'credits','./credits'),(28,'outstanding loans','./outstanding-loans'),(29,'questions','./questions'),(30,'configuration','./configuration'),(31,'dashboard','./dashboard'),(32,'accounts','./accounts'),(33,'credits','./credits'),(34,'outstanding loans','./outstanding-loans'),(35,'questions','./questions'),(36,'configuration','./configuration');
/*!40000 ALTER TABLE `user_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_module_level`
--

DROP TABLE IF EXISTS `user_module_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_module_level` (
  `id_user_module_level` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `module` int(11) NOT NULL,
  PRIMARY KEY (`id_user_module_level`),
  KEY `fk_lvl_idx` (`level`),
  KEY `fk_module_idx` (`module`),
  CONSTRAINT `fk_lvl` FOREIGN KEY (`level`) REFERENCES `user_level` (`id_level`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `fk_module` FOREIGN KEY (`module`) REFERENCES `user_module` (`id_module`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_module_level`
--

LOCK TABLES `user_module_level` WRITE;
/*!40000 ALTER TABLE `user_module_level` DISABLE KEYS */;
INSERT INTO `user_module_level` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,1),(8,1,2),(9,1,3),(10,1,4),(11,1,5),(12,1,6),(13,1,1),(14,1,2),(15,1,3),(16,1,4),(17,1,5),(18,1,6),(19,1,1),(20,1,2),(21,1,3),(22,1,4),(23,1,5),(24,1,6),(25,1,1),(26,1,2),(27,1,3),(28,1,4),(29,1,5),(30,1,6),(31,1,1),(32,1,2),(33,1,3),(34,1,4),(35,1,5),(36,1,6);
/*!40000 ALTER TABLE `user_module_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `fk_level_idx` (`level`),
  CONSTRAINT `fk_level` FOREIGN KEY (`level`) REFERENCES `user_level` (`id_level`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Marvin Escobar',1,'marvin@elaniin.com','mescobar','75269f82723397993cea7b8ef4286a53','22577777'),(2,'Eduardo Linares',2,'eduardo@elaniin.com','elinares','6825e00063b51fcf2bf28ea788064265','22577777');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-17 10:03:23
